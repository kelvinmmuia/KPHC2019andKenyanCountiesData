library(sf)

# List all shapefiles in the current directory
shapefiles <- list.files(pattern = "\\.shp$")

# Function to inspect a shapefile
inspect_shapefile <- function(shapefile) {
  cat("\nInspecting shapefile:", shapefile, "\n")
  
  # Read the shapefile
  data <- st_read(shapefile, quiet = TRUE)
  
  # Print the column names
  cat("Column Names:\n")
  print(names(data))
  
  # Print the first few rows of the data
  cat("\nFirst few rows:\n")
  print(head(data))
  
  # Print the geometry type
  cat("\nGeometry Type:\n")
  print(st_geometry_type(data))
  
  # Print the coordinate reference system (CRS)
  cat("\nCoordinate Reference System (CRS):\n")
  print(st_crs(data))
  
  # Print a summary of the geometries
  cat("\nGeometry Summary:\n")
  print(summary(st_geometry(data)))
}

# Loop through each shapefile and inspect it
for (shapefile in shapefiles) {
  inspect_shapefile(shapefile)
}
