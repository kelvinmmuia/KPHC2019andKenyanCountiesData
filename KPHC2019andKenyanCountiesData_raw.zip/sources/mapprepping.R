# Load your local shapefiles
county_sf <- st_read("ken_admbnda_adm1_iebc_20191031.shp", quiet = TRUE)
constituency_sf <- st_read("ken_admbnda_adm2_iebc_20191031.shp", quiet = TRUE)
wards_sf <- st_read("ken_admbndl_admALL_iebc_itos_20191031.shp", quiet = TRUE)
# Check column names
names(county_sf)
names(constituency_sf)
names(wards_sf)

list.files(path = ".", pattern = NULL, 
           all.files = FALSE, 
           full.names = FALSE, 
           recursive = FALSE,
           ignore.case = FALSE,
           include.dirs = FALSE, no.. = FALSE)

library(sf)
library(dplyr)
library(leaflet)
library(shiny)

# Read shapefiles
national_shape <- st_read("ken_admbndl_admALL_iebc_itos_20191031.shp")
county_shape <- st_read("ken_admbnda_adm1_iebc_20191031.shp")
constituency_shape <- st_read("ken_admbnda_adm2_iebc_20191031.shp")

national_shape <- national_shape %>% mutate(admin_level = "National")
county_shape <- county_shape %>% mutate(admin_level = "County")
constituency_shape <- constituency_shape %>% mutate(admin_level = "Constituency")

merged_shapes <- rbind(national_shape, county_shape, constituency_shape)

colnames(national_shape)
colnames(county_shape)
colnames(constituency_shape)


# Select relevant columns for each shapefile
national_shape_selected <- national_shape %>%
  dplyr::select(Shape_Leng, date, validTo, geometry, admin_level)

county_shape_selected <- county_shape %>%
  dplyr::select(Shape_Leng, Shape_Area, ADM0_EN, ADM0_PCODE, ADM1_EN, ADM1_PCODE, date, validTo, geometry, admin_level)

constituency_shape_selected <- constituency_shape %>%
  dplyr::select(Shape_Leng, Shape_Area, ADM0_EN, ADM0_PCODE, ADM1_EN, ADM1_PCODE, date, ValidTo, geometry, admin_level)

# Harmonize the column names across all shapefiles
colnames(national_shape_selected) <- c("Shape_Leng", "Shape_Area", "ADM0_EN", "ADM0_PCODE", "ADM1_EN", "ADM1_PCODE", "date", "validTo", "geometry", "admin_level")

# Combine the three shapefiles
merged_shape <- bind_rows(national_shape_selected, county_shape_selected, constituency_shape_selected)

# Ensure that the merged object is a valid sf object
merged_shape <- sf::st_as_sf(merged_shape)

