library(readxl)
library(dplyr)

# Create a data frame with GDP data
gdp_data <- data.frame(
  County = c("Nairobi County", "Kiambu County", "Mombasa County", "Nakuru County", "Kisumu County", 
             "Meru County", "Machakos County", "Kakamega County", "Nyandarua County", "Nyeri County", 
             "Narok County", "Bungoma County", "Murang'a County", "Kisii County", "Uasin Gishu County", 
             "Bomet County", "Elgeyo-Marakwet County", "Kericho County", "Nandi County", "Kilifi County", 
             "Trans Nzoia County", "Homa Bay County", "Kajiado County", "Embu County", "Nyamira County", 
             "Kitui County", "Makueni County", "Kirinyaga County", "Migori County", "Siaya County", 
             "Baringo County", "Busia County", "Kwale County", "Laikipia County", "Turkana County", 
             "Tharaka-Nithi County", "Vihiga County", "Taita Taveta County", "West Pokot County", 
             "Garissa County", "Wajir County", "Mandera County", "Marsabit County", "Tana River County", 
             "Lamu County", "Samburu County", "Isiolo County"),
  GDP_KSh_millions = c(5192323, 4933999, 989918, 832122, 645203, 632860, 629226, 629146, 619489, 
                       582563, 583509, 574961, 573018, 563546, 562273, 559569, 359531, 336799, 
                       219691, 219295, 216683, 214198, 207805, 203734, 203239, 201560, 200924, 
                       200836, 196337, 195265, 192866, 186712, 186278, 181095, 178301, 87692, 
                       79050, 71381, 66785, 59394, 57159, 45101, 44073, 43498, 42386, 36503, 
                       25850),
  GDP_USD_millions = c(30678, 20726, 9425, 7632, 5896, 5650, 5579, 5575, 5483, 4645, 4640, 
                       4493, 4455, 4266, 4240, 4186, 4185, 3732, 3390, 3382, 3330, 3280, 3153, 
                       3071, 2061, 2028, 2015, 2013, 1923, 1902, 1854, 1731, 1723, 1619, 1563, 
                       1352, 1179, 1026, 934, 887, 842, 801, 680, 669, 647, 529, 316)
)

# Clean county names by removing " County"
gdp_data$County <- gsub(" County", "", gdp_data$County)


# Add GDP per capita data
additional_gdp_data <- data.frame(
  County = c("Kiambu County", "Nairobi County", "Nyandarua County", "Mombasa County", "Nakuru County", 
             "Lamu County", "Elgeyo-Marakwet County", "Nyeri County", "Machakos County", "Embu County", 
             "Bomet County", "Tharaka-Nithi County", "Kisumu County", "Kirinyaga County", "Narok County", 
             "Murang'a County", "Laikipia County", "Busia County", "Meru County", "Nyamira County", 
             "Kericho County", "Taita Taveta County", "Uasin Gishu County", "Baringo County", "Nandi County", 
             "Kajiado County", "Kisii County", "Trans Nzoia County", "Tana River County", "Marsabit County", 
             "Makueni County", "Kwale County", "Isiolo County", "Homa Bay County", "Bungoma County", 
             "Kakamega County", "Siaya County", "Vihiga County", "Kitui County", "Samburu County", 
             "Garissa County", "Migori County", "Kilifi County", "Wajir County", "Turkana County", 
             "West Pokot County", "Mandera County"),
  GDP_per_capita_KSh = c(789129, 328575, 317700, 271039, 245999, 244379, 221467, 214885, 193460, 
                         183418, 169777, 169141, 168095, 162666, 160580, 156392, 154840, 154722, 
                         154537, 144512, 141047, 139053, 138350, 127437, 121149, 119557, 118858, 
                         108607, 106894, 106734, 104161, 101725, 100904, 99227, 97986, 95667, 
                         94714, 92572, 91580, 90143, 89502, 87960, 82405, 79468, 69775, 69589, 
                         48442),
  GDP_per_capita_USD = c(6955, 6561, 6344, 5412, 4912, 4880, 4422, 4291, 3863, 3662, 
                         3390, 3377, 3356, 3248, 3206, 3123, 3092, 3089, 3086, 2886, 
                         2816, 2777, 2763, 2545, 2419, 2387, 2373, 2169, 2134, 2131, 
                         2080, 2032, 2015, 1981, 1957, 1910, 1891, 1848, 1829, 1800, 
                         1787, 1756, 1645, 1587, 1393, 1390, 967)
)

# Clean county names
additional_gdp_data$County <- gsub(" County", "", additional_gdp_data$County)

# Merge additional GDP data into existing gdp_data
gdp_data <- gdp_data %>%
  left_join(additional_gdp_data, by = "County")

# Load the demographic data from the Excel file
demographic_data <- read_excel("county_demographic_data.xlsx")

# Clean and prepare the demographic data
demographic_data <- demographic_data %>%
  rename(
    County = County,
    Male = Male,
    Female = Female,
    Area_Km2 = `Sq. Km`,
    Persons_Per_Sq_Km = `Persons Per Sq. Km`)

# Merge the demographic data with the GDP data
merged_data <- gdp_data %>%
  left_join(demographic_data, by = "County")

# Write the merged data to a CSV file
write.csv(merged_data, "merged_data_with_demographics.csv", row.names = FALSE)

# Display the first few rows of the merged data
head(merged_data)

# Write the updated data to a CSV file
write.csv(merged_data, "gdp_data_with_population.csv", row.names = FALSE)


